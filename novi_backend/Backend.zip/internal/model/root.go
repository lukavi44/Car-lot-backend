package model

type Root struct {
	ID     string `json:"id"`
	Active bool   `json:"active"`
}
