package model

type Token struct {
	AccessToken string `json:"accessToken"`
	Role        string `json:"role"`
}
