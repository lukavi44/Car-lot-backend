package main

import "carshop/internal/server"

func main() {
	server.Start()
}
